global root_dir

root_dir = [pwd '\'];